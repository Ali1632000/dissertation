import 'package:flutter/material.dart';

const Color appbackgroundColor = Color.fromARGB(255, 255, 239, 230);
const Color appContainerColor = Color.fromARGB(255, 2, 137, 96);
const Color whiteColor = Colors.white;
