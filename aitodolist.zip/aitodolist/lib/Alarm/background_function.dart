class BackgroundFunction {
  static void myBackgroundHandler() {
    print('Received background notification');
    // Handle background notification here
  }
}
